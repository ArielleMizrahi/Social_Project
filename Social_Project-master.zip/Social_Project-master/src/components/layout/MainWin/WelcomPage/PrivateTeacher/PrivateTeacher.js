import Axios from 'axios';
import React, { Component } from 'react';
import InfoCard from '../InfoCard/InfoCard';
import axios from 'axios';


const Teachers =()=> {
 
  // function getTeacher(){
  //   axios.get('')
    

  // }

    return (
      <div>
        {/* <InfoCard dataItem={this.state} /> */}
      </div>
    );
  }


export default Teachers;

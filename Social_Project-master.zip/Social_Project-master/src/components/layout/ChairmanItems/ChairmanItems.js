import React, { Fragment } from 'react';
import CommDescription from '../CommiteesWin/commDescription/commDescription';
const chairmanItems = () => {
  return (
    <Fragment>
      <div className="container w-100">
        <CommDescription />
      </div>
    </Fragment>
  );
};

export default chairmanItems;

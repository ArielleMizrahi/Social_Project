import React from 'react';

const LoginDetails = () => {
  return (
    <div className="card text-right">
      <h1 className="card-header">ברוכים הבאים </h1>
      <div className="card-body">פה נירשום כמה דברים שיראו בכניסה</div>
    </div>
  );
};

export default LoginDetails;

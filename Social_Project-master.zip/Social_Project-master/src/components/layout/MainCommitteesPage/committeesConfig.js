export const committeesConfig = [
    {
        paramKey: "sport",
        name: 'ועדת ספורט',
        desc: 'פירוט רחב על כלל המידע הנוגע לועדה',
    },
    {
        paramKey: "education",
        name: 'ועדת חינוך',
        desc: 'פירוט רחב על כלל המידע הנוגע לועדה',
    },
    {
        paramKey: "education",
        name: 'ועדת תרבות',
        desc: 'פירוט רחב על כלל המידע הנוגע לועדה',
    }
]

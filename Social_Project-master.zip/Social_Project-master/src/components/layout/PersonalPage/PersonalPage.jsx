import React from "react";
import styles from "./PersonalPage.module.scss";

export const PersonalPage = () =>{
    return (
        <div className={styles.rootPersonalPage}>
            <h1>Personal Page</h1>
        </div>
    );
}
